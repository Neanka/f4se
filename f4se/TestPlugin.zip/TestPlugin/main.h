#pragma once

#include "f4se/PluginAPI.h"
#include "f4se_common/f4se_version.h"
#include <shlobj.h>
#include "f4se/GameAPI.h"
#include "f4se/GameData.h"
#include <string>
#include "f4se/GameForms.h"
#include "f4se/GameReferences.h"
#include "f4se/PapyrusNativeFunctions.h"